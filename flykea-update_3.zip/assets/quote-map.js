window.MAP_PATHS=["M298.5 497.4L309.6 525.5L322.4 543.1L343.0 538.5L357.6 536.2L375.8 523.3L387.5 519.6L411.0 526.9L415.6 548.0L414.1 573.4L419.9 605.9L434.1 604.5L456.5 602.6L456.3 619.2L456.9 636.8L415.3 643.7L428.4 727.1L403.7 748.6L338.8 735.6L251.2 738.0L225.3 727.9L202.8 735.5L203.7 704.0L212.0 676.0L223.7 648.7L242.4 625.8L243.5 598.6L231.7 578.5L227.7 561.6L227.8 533.3L213.1 506.1L223.6 499.3L237.0 497.2Z","M217.4 493.4L206.6 480.0L221.3 467.5L221.5 479.0L217.4 493.4Z","M1032.9 -130.1L1037.4 -125.4L1070.9 -128.2L1097.8 -141.6L1126.5 -167.8L1133.3 -144.3L1120.9 -130.6L1115.2 -123.6L1109.1 -106.5L1104.3 -93.7L1033.7 -125.3Z","M569.6 468.7L563.0 434.2L582.0 423.9L594.3 433.5L599.0 445.0L585.8 460.2L569.6 468.7Z","M14.4 244.6L-7.9 232.7L-11.2 180.5L-19.2 163.0L-22.9 145.9L-11.5 134.4L3.2 126.2L17.7 120.1L32.8 139.0L33.3 159.7L25.4 178.2L15.1 197.8L14.4 244.6Z","M-100.6 174.1L-124.6 169.5L-141.2 170.4L-154.3 158.9L-150.0 138.0L-133.9 113.7L-125.1 94.3L-106.3 92.9L-87.3 78.2L-63.9 63.0L-47.2 64.1L-35.5 74.1L-21.0 97.2L3.7 112.0L-1.3 132.5L-15.8 143.5L-41.2 145.4L-57.5 147.1L-102.9 146.6L-100.6 174.1Z","M492.7 761.2L503.4 776.9L535.9 802.1L542.1 822.6L571.5 835.2L523.3 866.1L510.1 887.8L495.1 899.5L479.7 910.8L452.8 904.0L433.8 906.3L418.9 922.5L393.5 933.9L390.8 913.9L372.8 891.0L393.4 829.5L409.5 754.6L449.6 755.9L469.2 747.6L484.7 744.5Z","M276.7 220.4L297.7 213.5L306.4 218.6L341.4 202.5L350.3 187.9L376.2 187.2L410.9 154.9L434.7 142.9L449.0 164.8L445.7 182.0L454.3 194.5L481.6 212.0L495.8 229.6L509.7 251.1L528.6 266.0L508.4 267.7L485.0 267.3L475.1 273.0L443.7 279.0L431.3 278.5L409.6 287.0L381.1 277.3L352.8 276.9L342.8 302.0L315.3 297.3L291.9 327.8L288.8 312.2L271.6 294.8L260.0 276.4L259.6 261.4L266.2 241.5Z","M-101.2 270.9L-125.2 267.1L-163.2 271.0L-198.3 284.6L-200.7 266.9L-199.4 256.1L-214.8 246.0L-216.4 231.0L-217.5 214.9L-213.0 205.8L-212.6 198.8L-210.0 179.7L-213.1 164.0L-206.2 160.5L-184.4 163.8L-177.0 158.1L-167.7 164.7L-154.3 158.9L-141.2 170.4L-124.6 169.5L-100.6 174.1L-103.8 221.3L-100.2 262.7Z","M230.7 327.8L215.8 329.3L193.3 327.9L162.4 311.0L144.8 293.7L135.2 281.3L140.8 260.8L156.7 240.6L177.0 228.0L203.0 229.6L209.7 212.5L224.0 193.4L232.7 174.2L241.1 150.0L259.8 127.0L253.8 114.9L260.3 107.1L270.0 134.3L280.6 167.0L263.1 168.3L249.0 176.1L270.4 191.7L279.9 214.7L266.2 241.5L259.6 261.4L260.0 276.4L271.6 294.8L288.8 312.2L291.9 327.8L273.9 334.1L230.7 327.8Z","M600.7 301.9L607.8 329.1L593.1 342.0L580.7 362.6L574.7 387.2L568.6 408.8L564.9 422.8L568.3 443.6L573.3 487.9L575.4 510.8L598.8 548.8L562.6 550.1L551.0 565.9L552.0 599.8L555.1 624.4L575.3 628.7L561.1 651.0L544.9 630.7L524.3 616.8L494.8 620.5L474.6 609.1L463.7 603.2L447.0 601.4L425.1 604.0L421.0 581.1L412.5 560.6L411.4 540.0L385.7 527.1L376.9 519.6L362.9 524.1L354.5 541.4L336.1 541.4L314.4 532.2L303.6 513.0L237.0 497.2L223.6 499.3L212.1 495.6L218.1 484.3L229.1 474.6L241.7 468.8L254.4 474.9L274.4 465.5L291.8 448.6L300.1 411.3L323.4 390.5L326.3 376.2L328.6 357.2L335.3 325.7L342.8 302.0L352.8 276.9L381.1 277.3L409.6 287.0L431.3 278.5L443.7 279.0L475.1 273.0L485.0 267.3L508.4 267.7L528.6 266.0L550.6 285.7L565.8 283.6L582.4 288.0Z","M229.1 474.6L215.0 471.0L189.5 457.9L197.5 432.6L218.7 424.8L231.5 425.6L256.2 416.6L256.6 386.5L255.8 350.1L235.1 347.6L230.7 327.8L273.9 334.1L291.9 327.8L315.3 297.3L342.8 302.0L335.3 325.7L328.6 357.2L326.3 376.2L323.4 390.5L300.1 411.3L291.8 448.6L274.4 465.5L254.4 474.9L241.7 468.8L229.1 474.6Z","M855.9 110.4L860.1 125.5L857.2 136.2L844.9 143.6L828.2 144.8L826.3 132.7L840.7 113.7L855.9 110.4Z","M208.3 -114.0L76.6 -33.4L24.1 -22.0L14.2 -38.7L-3.7 -54.4L-144.2 -145.3L-222.2 -199.8L-222.4 -225.9L-167.9 -244.4L-142.9 -260.4L-117.7 -284.1L-96.2 -293.6L-65.1 -305.2L-77.8 -331.7L-86.9 -357.7L-44.3 -372.7L-11.1 -387.6L58.7 -393.0L88.8 -398.1L119.5 -393.5L129.5 -384.0L127.9 -347.0L116.9 -319.7L134.1 -302.2L155.9 -256.4L163.7 -228.3L161.6 -201.8L160.8 -177.3L164.8 -153.4L173.0 -132.9L199.2 -127.0Z","M685.9 -239.6L675.6 -215.5L665.0 -201.0L648.7 -217.0L631.7 -245.0L653.1 -202.1L676.5 -158.3L701.9 -123.5L698.5 -106.3L726.4 -83.3L562.9 -83.3L479.2 -160.1L472.9 -250.9L475.1 -272.7L510.3 -283.0L551.1 -271.4L576.7 -274.7L603.7 -282.4L624.2 -269.4L645.7 -271.3L672.2 -275.4Z","M840.7 113.7L825.0 94.7L810.3 80.9L777.9 72.3L760.7 72.8L741.5 78.9L715.1 66.2L726.1 21.7L748.0 11.9L770.6 24.2L787.8 53.4L827.8 85.0L845.6 104.2L849.6 115.5Z","M748.0 63.3L772.9 67.9L792.2 72.5L815.7 88.1L833.5 107.0L833.3 122.9L827.9 138.4L839.9 145.1L849.5 147.4L852.7 166.2L868.3 183.7L953.9 208.3L867.9 271.7L836.0 286.8L816.1 293.4L788.6 295.0L768.6 302.1L759.1 300.2L726.1 282.3L704.5 275.5L693.7 260.3L671.9 232.8L657.7 214.3L652.0 200.9L666.1 194.1L672.0 153.5L684.0 139.2L705.5 113.0L717.3 74.5L748.0 63.3Z","M189.5 457.9L154.3 419.7L142.3 391.2L151.9 369.4L163.1 352.8L193.3 327.9L215.8 329.3L230.7 327.8L235.1 347.6L255.8 350.1L256.6 386.5L256.2 416.6L231.5 425.6L218.7 424.8L197.5 432.6L189.5 457.9Z","M-19.6 251.5L-63.8 270.8L-101.2 270.9L-109.3 244.8L-95.0 203.8L-103.4 158.4L-66.7 145.6L-50.8 143.8L-42.7 151.9L-34.0 177.8L-26.8 201.8L-29.8 231.0L-19.6 251.5Z","M156.1 354.0L152.2 350.8L159.4 327.4L193.3 327.9L193.4 353.0L163.1 352.8L156.1 354.0Z","M1081.7 -400.0L1114.8 -415.9L1137.9 -419.2L1175.8 -406.7L1216.2 -386.0L1233.6 -367.7L1219.3 -326.6L1219.5 -312.1L1228.0 -282.3L1245.4 -265.3L1236.9 -235.5L1265.2 -213.7L1275.7 -192.0L1247.4 -171.7L1200.3 -153.8L1154.1 -161.2L1135.3 -190.5L1098.2 -176.7L1051.7 -199.6L1017.8 -225.3L991.2 -249.7L970.2 -248.5L958.4 -270.5L955.2 -285.6L918.9 -312.9L909.3 -348.9L918.3 -368.3L891.1 -399.4L883.8 -422.5L891.5 -452.4L905.4 -434.9L927.2 -432.7L959.6 -449.6L958.6 -433.2L976.7 -423.3L1003.1 -403.6L1047.2 -389.6L1081.7 -400.0Z","M904.6 -374.5L919.8 -356.1L904.5 -332.7L944.5 -301.4L951.8 -270.5L958.6 -259.4L957.8 -249.5L928.5 -231.2L831.0 -274.8L774.9 -295.0L812.6 -342.1L818.5 -382.5L840.6 -400.6L873.8 -401.2L891.1 -399.4Z","M702.5 -306.4L691.3 -302.8L692.2 -286.5L686.0 -278.2L696.3 -272.9L672.2 -275.4L676.8 -283.4L686.6 -308.9L690.1 -314.4L699.0 -318.0L704.9 -309.8L702.5 -306.4Z","M698.9 -299.9L725.7 -298.2L774.9 -295.0L729.2 -281.4L743.1 -257.1L723.8 -247.2L709.8 -233.3L685.9 -239.6L695.8 -281.0L698.9 -299.9Z","M812.4 392.9L810.1 418.4L797.1 428.6L787.5 451.7L775.0 472.4L743.7 439.5L664.7 394.8L670.4 364.3L688.2 335.3L676.6 300.9L679.6 274.0L704.5 263.8L711.6 282.3L752.5 300.0L764.0 299.7L782.5 303.7L807.7 286.3L830.3 293.4L812.4 392.9Z","M957.8 -249.5L960.3 -235.5L952.3 -219.3L928.5 -231.2L957.8 -249.5Z","M267.7 -101.3L241.3 -105.0L199.2 -127.0L173.0 -132.9L164.8 -153.4L160.8 -177.3L161.6 -201.8L163.7 -228.3L155.9 -256.4L167.8 -270.0L179.9 -286.7L196.5 -299.4L222.2 -308.2L248.3 -306.5L285.7 -278.7L333.8 -265.9L366.1 -261.0L371.3 -286.5L392.8 -306.4L435.3 -305.0L450.2 -295.6L477.5 -289.6L475.1 -272.7L472.9 -250.9L479.2 -160.1L479.2 -41.7L455.0 -32.9L288.8 -112.7Z","M990.5 634.8L1001.2 657.4L1009.9 692.2L1004.2 708.3L993.2 702.3L995.3 726.6L988.2 749.0L969.8 802.0L948.9 870.5L922.6 899.6L892.4 903.0L870.1 884.6L861.4 849.5L863.2 819.5L872.8 809.0L884.7 779.9L875.9 756.9L881.5 726.1L894.7 712.1L914.0 704.0L935.0 691.9L958.4 668.6L964.5 662.2L976.3 635.2L990.5 634.8Z","M-295.2 70.5L-284.7 54.4L-263.6 59.7L-243.8 57.0L-157.0 52.0L-156.0 34.9L-176.1 -144.9L-74.0 -99.8L1.3 -44.6L23.9 -35.3L47.2 -24.1L35.9 37.8L15.6 54.0L-20.5 63.2L-47.2 64.1L-63.9 63.0L-87.3 78.2L-106.3 92.9L-125.1 94.3L-133.9 113.7L-150.0 138.0L-154.3 158.9L-167.7 164.7L-177.0 158.1L-184.4 163.8L-206.2 160.5L-215.3 156.4L-216.8 147.7L-220.4 143.0L-224.7 128.9L-231.8 118.6L-241.0 121.0L-253.4 128.2L-268.1 121.3L-277.0 123.4L-281.5 115.8L-282.4 101.2L-294.3 83.4Z","M678.3 615.0L719.0 619.2L739.0 616.0L758.9 610.1L798.3 589.9L800.8 620.0L804.2 670.9L801.6 696.0L780.3 723.4L737.7 741.4L706.2 767.5L683.0 787.2L691.2 817.8L695.5 836.2L698.6 855.6L700.2 868.9L688.3 885.0L646.1 903.3L638.8 919.8L642.3 932.1L624.7 922.7L619.8 905.9L618.1 867.9L630.1 814.9L638.7 798.0L637.7 779.6L642.7 749.6L631.8 716.5L617.4 709.8L590.4 705.9L587.1 683.3L662.3 676.1L676.2 679.4L673.1 697.5L688.2 725.0L703.6 706.2L693.1 664.3L678.3 657.9L678.3 615.0Z","M-295.2 70.5L-321.6 40.8L-345.4 29.2L-367.2 34.0L-384.6 38.9L-380.6 17.4L-380.4 -22.8L-380.8 -43.6L-397.2 -62.5L-311.0 -69.3L-309.9 -110.1L-291.0 -165.3L-222.6 -195.7L-176.1 -144.9L-156.0 34.9L-157.0 52.0L-243.8 57.0L-263.6 59.7L-284.7 54.4L-295.2 70.5Z","M678.3 615.0L678.3 657.9L693.1 664.3L703.6 706.2L688.2 725.0L673.1 697.5L676.2 679.4L662.3 676.1L639.3 660.7L652.2 634.1L652.4 599.9L650.7 576.6L661.2 571.2L672.5 586.7Z","M298.9 970.3L275.2 939.4L265.5 904.0L258.0 847.0L247.3 827.1L225.6 784.9L204.1 751.4L212.8 731.5L238.8 728.6L254.4 736.5L353.3 745.6L442.0 740.1L472.5 736.5L480.9 743.0L462.9 747.7L441.6 747.3L394.0 755.3L372.8 830.2L372.8 967.9L343.0 980.1L320.6 974.7L308.8 960.0Z","M3.2 126.2L-20.3 107.3L-32.7 83.6L-33.9 64.0L-12.8 55.8L34.1 50.7L47.3 23.9L76.6 -33.4L208.3 -114.0L253.0 -93.6L272.9 -68.9L281.0 -56.9L285.1 -40.8L276.0 28.6L240.4 75.7L249.1 96.8L260.3 107.1L253.8 114.9L235.8 92.6L214.6 103.4L187.3 96.1L169.1 98.4L146.1 107.8L111.1 102.1L92.6 93.9L49.3 88.6L41.0 105.1L33.6 132.1L10.2 120.1Z","M135.4 275.6L105.9 282.0L81.2 286.2L63.2 258.1L32.8 244.6L15.6 211.0L19.0 184.6L35.5 165.3L37.4 151.4L33.6 132.1L41.0 105.1L49.3 88.6L92.6 93.9L111.1 102.1L146.1 107.8L169.1 98.4L187.3 96.1L214.6 103.4L235.8 92.6L253.8 114.9L259.8 127.0L241.1 150.0L232.7 174.2L224.0 193.4L209.7 212.5L203.0 229.6L177.0 228.0L156.7 240.6L140.8 260.8Z","M1184.6 -64.9L1167.4 -51.7L1159.7 -36.2L1160.3 -19.7L1137.7 -12.0L1130.9 2.6L1109.8 7.7L1099.8 21.9L1074.4 26.9L1058.0 13.5L1104.2 -41.7L1108.5 -98.1L1115.1 -115.1L1124.6 -127.7L1122.6 -144.2L1142.6 -130.0L1169.5 -119.7L1191.3 -104.0L1204.3 -94.5L1196.7 -77.4L1184.6 -64.9Z","M1133.2 -164.5L1130.4 -160.7L1126.5 -167.8L1132.5 -174.9L1135.1 -173.1L1133.2 -164.5Z","M1016.9 -140.7L1021.1 -166.8L1033.1 -162.5L1029.0 -138.1L1016.9 -140.7Z","M592.1 398.6L599.1 422.7L582.0 423.9L563.0 434.2L567.8 421.1L574.6 402.9L592.1 398.6Z","M849.6 34.4L840.6 19.3L828.2 3.5L811.2 -31.0L787.5 -48.7L771.3 -83.1L760.3 -118.5L739.2 -130.9L733.5 -147.6L721.7 -163.0L700.8 -195.3L679.8 -209.6L684.0 -228.3L709.8 -233.3L723.8 -247.2L743.1 -257.1L729.2 -281.4L774.9 -295.0L831.0 -274.8L928.5 -231.2L952.3 -219.3L975.2 -201.9L989.0 -189.8L1004.4 -172.4L1005.0 -158.5L1013.8 -145.8L1023.2 -136.6L1032.9 -130.1L1041.7 -104.2L1108.5 -98.1L1104.2 -41.7L981.6 -12.8L947.2 18.4L932.3 14.9L904.2 13.9L876.3 12.3L862.1 8.8L858.7 27.8Z","M665.9 177.8L663.4 167.0L650.1 151.7L650.1 121.3L639.1 124.5L631.5 131.6L621.9 155.6L600.8 172.8L575.4 164.9L562.5 174.9L541.1 179.2L523.2 174.2L509.9 176.0L495.6 158.1L474.9 170.6L462.4 193.2L454.3 194.5L445.7 182.0L449.0 164.8L434.7 142.9L427.3 131.7L422.7 111.5L417.4 105.1L420.5 87.8L423.0 76.5L438.0 48.3L455.0 -32.9L479.2 -41.7L562.9 -83.3L726.4 -83.3L728.5 -59.1L739.2 -12.8L758.5 0.0L732.7 15.4L724.0 35.6L717.3 74.5L705.5 113.0L684.0 139.2L672.0 153.5L665.9 177.8Z","M665.9 177.8L663.0 200.4L644.9 212.8L668.2 224.5L681.4 237.6L679.6 274.0L654.0 296.0L622.5 300.9L600.7 301.9L577.4 279.1L556.2 282.2L541.2 283.2L525.3 259.4L504.4 238.6L481.8 218.7L470.2 203.6L462.4 193.2L474.9 170.6L495.6 158.1L509.9 176.0L523.2 174.2L541.1 179.2L562.5 174.9L575.4 164.9L600.8 172.8L621.9 155.6L631.5 131.6L639.1 124.5L650.1 121.3L650.1 151.7L663.4 167.0L665.9 177.8Z","M977.9 178.1L953.9 208.3L868.3 183.7L852.7 166.2L849.5 147.4L864.0 140.0L877.5 157.4L907.4 152.1L948.5 143.2L966.2 138.0L978.0 137.6L977.9 167.2Z","M994.3 133.8L1015.3 124.5L1023.6 130.2L1021.8 153.3L1011.5 183.4L988.6 233.2L952.9 287.1L907.6 332.4L857.0 368.9L829.4 405.1L812.4 392.9L830.3 293.4L849.4 286.4L895.1 270.8L968.5 190.9L977.9 167.2L978.0 137.6L984.7 136.9Z","M260.3 107.1L249.1 96.8L240.4 75.7L276.0 28.6L285.1 -40.8L281.0 -56.9L272.9 -68.9L288.8 -112.7L455.0 -32.9L438.0 48.3L423.0 76.5L420.5 87.8L417.4 105.1L422.7 111.5L427.3 131.7L434.7 142.9L410.9 154.9L376.2 187.2L350.3 187.9L341.4 202.5L306.4 218.6L297.7 213.5L276.7 220.4L273.4 200.4L261.3 188.2L253.6 166.2L268.9 166.8L269.2 148.1L268.6 120.4Z","M-2.8 247.0L-24.2 244.2L-31.4 220.6L-32.1 194.2L-34.0 162.7L-41.2 145.4L-25.6 156.9L-12.0 170.3L-7.0 184.8L-2.8 247.0Z","M664.7 394.8L743.7 439.5L775.0 472.4L766.7 509.9L780.6 522.9L776.1 541.8L782.0 564.8L798.3 589.9L758.9 610.1L739.0 616.0L719.0 619.2L678.3 615.0L665.4 577.0L640.8 567.3L615.8 557.5L598.8 548.8L575.4 510.8L573.3 487.9L578.2 467.8L593.9 449.3L598.8 438.2L593.1 425.3L600.3 410.4L599.4 396.1L664.7 394.8Z","M622.2 396.4L592.1 398.6L574.6 402.9L579.6 379.3L585.1 352.9L601.1 336.5L599.4 326.3L609.3 296.2L639.3 296.0L666.8 286.5L679.1 311.4L680.7 350.5L664.4 372.7L622.2 396.4Z","M1064.8 28.1L1045.7 42.9L1024.4 58.8L972.5 83.3L957.1 83.2L931.6 95.8L908.9 98.1L898.8 105.1L885.3 110.0L864.2 111.7L859.4 88.2L851.9 66.6L850.1 57.0L850.5 43.5L858.7 27.8L862.1 8.8L876.3 12.3L904.2 13.9L932.3 14.9L947.2 18.4L981.6 -12.8L1058.0 13.5Z","M640.8 567.3L656.0 594.3L648.2 616.8L645.7 641.3L650.3 666.1L589.0 698.1L561.4 709.2L551.4 718.1L521.8 748.7L508.0 746.8L480.9 743.0L472.5 736.5L442.0 740.1L414.3 710.0L458.7 644.0L460.0 629.0L458.7 609.1L463.7 603.2L474.6 609.1L494.8 620.5L524.3 616.8L544.9 630.7L561.1 651.0L575.3 628.7L555.1 624.4L552.0 599.8L551.0 565.9L562.6 550.1L598.8 548.8L615.8 557.5L640.8 567.3Z","M608.2 838.6L590.1 839.0L571.5 835.2L542.1 822.6L535.9 802.1L503.4 776.9L492.7 761.2L508.0 746.8L521.8 748.7L551.4 718.1L561.4 709.2L589.0 698.1L607.8 705.4L621.9 715.0L642.7 723.2L638.6 764.0L641.1 785.7L635.6 799.9L608.2 838.6Z"];window.MAP_VB=[0,0,1000,625];window.MAP_BBOX=[2,50,-12,18];

/* ===== KEA instant charter quote + route map (shared) ===== */
(function(){
"use strict";
/* ---- EDITABLE CONFIG (KEA) ---- rack USD/block-hr; NET (x0.9) is internal, never shown ---- */
var WA_NUMBER="256776333114", BOOK_EMAIL="reservations@flykea.com";
var DAY_STOP=500, RANGE_PCT=0.10, TAXI=0.5;   // taxi/climb hrs added to block
var FLEET=[
 {id:"c206", name:"Cessna 206",            cruise:140, pax:5,  range:600, rate:950,  min:700,  day:450,  heli:false, note:"light, economical"},
 {id:"c210", name:"Cessna 210",            cruise:165, pax:5,  range:700, rate:1100, min:800,  day:450,  heli:false, note:"light, faster"},
 {id:"c208", name:"Cessna Caravan 208EX",  cruise:175, pax:12, range:900, rate:1800, min:1600, day:800,  heli:false, note:"short / rough strips"},
 {id:"as350",name:"Airbus AS350 B3+",      cruise:120, pax:5,  range:350, rate:2200, min:1500, day:1000, heli:true,  note:"helicopter, site access"},
 {id:"b412", name:"Bell 412",              cruise:120, pax:13, range:360, rate:4500, min:2800, day:1000, heli:true,  note:"helicopter, 13 seats"},
 {id:"b1900",name:"Beechcraft 1900D",      cruise:280, pax:19, range:450, rate:3800, min:3200, day:1000, heli:false, note:"up to 19 seats"}
];
function ac(id){return FLEET.filter(function(a){return a.id===id;})[0];}
/* country: UG = instant range; others = fast-response */
var PORTS=[
 ["Kajjansi (Kampala)",0.196,32.553,"UG"],["Entebbe (EBB)",0.042,32.443,"UG"],["Arua",2.98,30.92,"UG"],
 ["Gulu",2.78,32.27,"UG"],["Pakuba / Murchison",2.32,31.55,"UG"],["Bugungu",2.27,31.49,"UG"],
 ["Chobe",2.27,32.23,"UG"],["Kidepo",3.72,33.95,"UG"],["Kihihi",-0.68,29.70,"UG"],["Kasese",0.18,30.10,"UG"],
 ["Kisoro",-1.28,29.72,"UG"],["Mbarara",-0.55,30.60,"UG"],["Masaka",-0.33,31.73,"UG"],["Fort Portal",0.66,30.25,"UG"],
 ["Semliki",0.83,30.05,"UG"],["Mweya",-0.20,29.90,"UG"],["Jinja",0.45,33.12,"UG"],["Soroti",1.73,33.62,"UG"],
 ["Tororo",0.68,34.16,"UG"],["Lira",2.25,32.92,"UG"],["Pader",2.80,33.18,"UG"],["Kotido",2.98,34.13,"UG"],
 ["Kaabong",3.51,34.12,"UG"],["Moroto",2.52,34.62,"UG"],["Moyo",3.65,31.77,"UG"],["Amudat",1.95,34.91,"UG"],
 ["Kinyara",1.72,32.00,"UG"],
 ["Juba (S. Sudan)",4.87,31.60,"SS"],["Malakal (S. Sudan)",9.56,31.65,"SS"],["Bunia (DRC)",1.57,30.22,"CD"],
 ["Goma (DRC)",-1.67,29.24,"CD"],["Kalemie (DRC)",-5.88,29.25,"CD"],["Kinshasa (DRC)",-4.39,15.44,"CD"],
 ["Nairobi (Wilson)",-1.32,36.81,"KE"],["Mombasa",-4.03,39.59,"KE"],["Kigali (Rwanda)",-1.97,30.14,"RW"],
 ["Mwanza (TZ)",-2.44,32.93,"TZ"],["Dar es Salaam",-6.87,39.20,"TZ"],["Mogadishu (Somalia)",2.01,45.30,"SO"],
 ["N'Djamena (Chad)",12.13,15.03,"TD"],["Abeche (Chad)",13.85,20.84,"TD"],["Bangui (CAR)",4.40,18.52,"CF"],
 ["Addis Ababa",8.98,38.80,"ET"],["Erbil (Kurdistan)",36.24,43.96,"IQ"]
];
var BB=window.MAP_BBOX,VB=window.MAP_VB,PATHS=window.MAP_PATHS,NS="http://www.w3.org/2000/svg";
function proj(lon,lat){return [(lon-BB[0])/(BB[1]-BB[0])*VB[2],(BB[3]-lat)/(BB[3]-BB[2])*VB[3]];}
function hav(a,b){var R=6371,r=Math.PI/180,dLa=(b[0]-a[0])*r,dLo=(b[1]-a[1])*r,la1=a[0]*r,la2=b[0]*r;
 var x=Math.sin(dLa/2)*Math.sin(dLa/2)+Math.cos(la1)*Math.cos(la2)*Math.sin(dLo/2)*Math.sin(dLo/2);
 return (R*2*Math.atan2(Math.sqrt(x),Math.sqrt(1-x)))/1.852;}
function findPort(n){n=(n||"").trim().toLowerCase();if(!n)return null;var f=PORTS.filter(function(p){return p[0].toLowerCase()===n;});
 if(!f.length)f=PORTS.filter(function(p){return p[0].toLowerCase().indexOf(n)>=0;});return f[0]||null;}
function inUG(lat,lon){return lat>-1.6&&lat<4.3&&lon>29.4&&lon<35.1;}
function recommend(dist,pax,heli){
 if(heli){return pax<=5?ac("as350"):ac("b412");}
 var c=FLEET.filter(function(a){return !a.heli&&a.pax>=pax&&a.range>=dist*0.6;});
 if(!c.length)c=FLEET.filter(function(a){return !a.heli&&a.pax>=pax;});
 if(!c.length)c=[ac("b1900")];
 c.sort(function(x,y){return (x.pax-pax)-(y.pax-pax) || x.rate-y.rate;});
 return c[0];
}
function fmtTime(h){var m=Math.round(h*60);return Math.floor(m/60)+"h "+("0"+(m%60)).slice(-2)+"m";}
function money(n){return "$"+(Math.round(n/50)*50).toLocaleString("en-US");}
function priceRange(a,oneway,dayStop){var block=oneway*2+TAXI;var p=Math.max(a.min,block*a.rate);if(dayStop)p+=(a.day||DAY_STOP);
 return [money(p*(1-RANGE_PCT)),money(p*(1+RANGE_PCT))];}
function el(t,a){var e=document.createElementNS(NS,t);for(var k in a)e.setAttribute(k,a[k]);return e;}
function fillDatalist(){var dl=document.getElementById("qports");if(!dl||dl.childElementCount)return;
 PORTS.forEach(function(p){var o=document.createElement("option");o.value=p[0];dl.appendChild(o);});}
function buildMap(svg){
 for(var lon=5;lon<=50;lon+=5){var a=proj(lon,BB[3]),b=proj(lon,BB[2]);svg.appendChild(el("line",{x1:a[0],y1:a[1],x2:b[0],y2:b[1],"class":"qgrat"}));}
 for(var lat=-10;lat<=15;lat+=5){var c=proj(BB[0],lat),d=proj(BB[1],lat);svg.appendChild(el("line",{x1:c[0],y1:c[1],x2:d[0],y2:d[1],"class":"qgrat"}));}
 PATHS.forEach(function(p){svg.appendChild(el("path",{d:p,"class":"qcountry"}));});
 PORTS.forEach(function(p){var xy=proj(p[2],p[1]);svg.appendChild(el("circle",{cx:xy[0],cy:xy[1],r:1.8,"class":"qnode"}));});
 var g=el("g",{"class":"qlayer"});svg.appendChild(g);return g;}
function drawRoute(layer,A,B){
 while(layer.firstChild)layer.removeChild(layer.firstChild);
 var a=proj(A[2],A[1]),b=proj(B[2],B[1]),mx=(a[0]+b[0])/2,my=(a[1]+b[1])/2,dx=b[0]-a[0],dy=b[1]-a[1],len=Math.hypot(dx,dy)||1;
 var off=Math.min(len*0.18,80),cx=mx-dy/len*off,cy=my+dx/len*off;
 var rp=el("path",{d:"M"+a[0]+" "+a[1]+" Q"+cx+" "+cy+" "+b[0]+" "+b[1],"class":"qroute"});layer.appendChild(rp);
 [[a,A[0]],[b,B[0]]].forEach(function(z){layer.appendChild(el("circle",{cx:z[0][0],cy:z[0][1],r:8,"class":"qpulse"}));
  layer.appendChild(el("circle",{cx:z[0][0],cy:z[0][1],r:4,"class":"qpt"}));
  var t=el("text",{x:z[0][0]+8,y:z[0][1]-9,"class":"qlbl"});t.textContent=z[1];layer.appendChild(t);});
 var plane=el("path",{"class":"qplane",d:"M2 0 L-9 4 L-6 0 L-9 -4 Z",transform:"translate(-200,-200)"});layer.appendChild(plane);
 var L=rp.getTotalLength();rp.style.strokeDasharray=L;rp.style.strokeDashoffset=L;
 if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){rp.style.strokeDashoffset=0;var e=rp.getPointAtLength(L);plane.setAttribute("transform","translate("+e.x+","+e.y+") scale(1.6)");return;}
 var t0=null,dur=1600;
 (function step(ts){if(!t0)t0=ts;var k=Math.min((ts-t0)/dur,1),e=1-Math.pow(1-k,3);rp.style.strokeDashoffset=L*(1-e);
  var p=rp.getPointAtLength(L*e),p2=rp.getPointAtLength(Math.min(L*e+1,L)),ang=Math.atan2(p2.y-p.y,p2.x-p.x)*180/Math.PI;
  plane.setAttribute("transform","translate("+p.x+","+p.y+") rotate("+ang+") scale(1.6)");if(k<1)requestAnimationFrame(step);})(0);}
function set(root,sel,txt){var e=root.querySelector(sel);if(e)e.textContent=txt;}
function show(root,sel,on){var e=root.querySelector(sel);if(e)e.style.display=on?"":"none";}

function initTool(root){
 if(root._init)return; root._init=1;
 var svg=root.querySelector(".qmap-map"),layer=svg?buildMap(svg):null;
 fillDatalist();
 var dEl=root.querySelector(".q-date");if(dEl&&!dEl.value){var dt=new Date(Date.now()+3*864e5);dEl.value=dt.toISOString().slice(0,10);}
 // populate override dropdown once
 var ov=root.querySelector(".q-override");
 if(ov&&!ov.childElementCount){FLEET.forEach(function(a){var o=document.createElement("option");o.value=a.id;o.textContent=a.name;ov.appendChild(o);});}
 var last={};
 function compute(forceId){
  var A=findPort((root.querySelector(".q-from")||{}).value);
  var coordEl=root.querySelector(".q-coord"), coordRaw=(coordEl&&coordEl.value||"").trim();
  var B=findPort((root.querySelector(".q-to")||{}).value), bLabel, bCountry;
  var m=coordRaw.match(/(-?\d+\.?\d*)[ ,]+(-?\d+\.?\d*)/);
  if(m){var la=parseFloat(m[1]),lo=parseFloat(m[2]);B=["Custom site",la,lo,inUG(la,lo)?"UG":"XX"];bLabel=la.toFixed(3)+", "+lo.toFixed(3);}
  if(!A||!B){return null;}
  bLabel=bLabel||B[0];
  var pax=Math.max(1,+((root.querySelector(".q-pax")||{}).value)||1);
  var mEl=root.querySelector(".q-mission"),mission=mEl?mEl.value:"pax";
  var heli=(mission==="site")||!!m;
  var dist=hav([A[1],A[2]],[B[1],B[2]]);
  var aircraft = forceId?ac(forceId):recommend(dist,pax,heli);
  var oneway=dist/aircraft.cruise;
  var intl=(A[3]!=="UG")||(B[3]!=="UG");
  return {A:A,B:B,bLabel:bLabel,pax:pax,mission:mission,dist:dist,ac:aircraft,oneway:oneway,intl:intl,m:m};
 }
 function render(st,animate){
  last=st;
  if(layer&&animate)drawRoute(layer,st.A,[st.bLabel,st.B[1],st.B[2]]);
  set(root,".q-dist",Math.round(st.dist)+" nm");
  set(root,".q-time",fmtTime(st.oneway+TAXI/2));
  set(root,".q-ac",st.ac.name);
  set(root,".q-acnote",st.ac.note);
  var ov=root.querySelector(".q-override");if(ov)ov.value=st.ac.id;
  var dsa=root.querySelector(".q-daystopamt");if(dsa)dsa.textContent="$"+(st.ac.day||DAY_STOP);
  var dayStop=!!(root.querySelector(".q-daystop")||{}).checked;
  if(st.intl){
   show(root,".q-priceblock",false); show(root,".q-intl",true);
  }else{
   show(root,".q-priceblock",true); show(root,".q-intl",false);
   var r=priceRange(st.ac,st.oneway,dayStop);
   set(root,".q-price",r[0]+" – "+r[1]);
  }
  var res=root.querySelector(".qmap-result");if(res)res.classList.add("show");
  var qc=root.querySelector(".qc-result");if(qc)qc.classList.add("show");
  var see=root.querySelector(".q-see");if(see&&st.A&&st.B)see.href="/quote/?from="+encodeURIComponent(st.A[0])+"&to="+encodeURIComponent(st.B[0])+"&pax="+st.pax;
 }
 function run(animate){var st=compute(null);if(st)render(st,animate!==false);}
 var go=root.querySelector(".q-go");if(go)go.addEventListener("click",function(){run(true);});
 var ov2=root.querySelector(".q-override");if(ov2)ov2.addEventListener("change",function(){var st=compute(this.value);if(st)render(st,false);});
 var ds=root.querySelector(".q-daystop");if(ds)ds.addEventListener("change",function(){if(last.ac)render(last,false);});
 var sw=root.querySelector(".q-swap");if(sw)sw.addEventListener("click",function(){var f=root.querySelector(".q-from"),t=root.querySelector(".q-to"),x=f.value;f.value=t.value;t.value=x;run(true);});
 root.querySelectorAll(".q-from,.q-to,.q-coord").forEach(function(i){i.addEventListener("keydown",function(e){if(e.key==="Enter")run(true);});});
 function leadOk(){var em=root.querySelector(".q-email"),ph=root.querySelector(".q-phone");
  if(em&&!em.value.trim()){em.focus();flash(em);return false;}
  if(ph&&!ph.value.trim()){ph.focus();flash(ph);return false;} return true;}
 function flash(e){e.style.outline="2px solid #d9534f";setTimeout(function(){e.style.outline="";},1500);}
 function lead(){return {email:(root.querySelector(".q-email")||{}).value||"",phone:(root.querySelector(".q-phone")||{}).value||""};}
 var wa=root.querySelector(".q-wa");
 if(wa)wa.addEventListener("click",function(e){
   if(!last.ac){e.preventDefault();run(true);return;}
   if(!leadOk()){e.preventDefault();return;}
   var l=lead(),date=(root.querySelector(".q-date")||{}).value||"(flexible)",dayStop=!!(root.querySelector(".q-daystop")||{}).checked;
   var msg="Charter quote request — KEA\n From: "+last.A[0]+"\n To: "+last.bLabel+"\n Date: "+date+"\n Passengers: "+last.pax+
    "\n Aircraft: "+last.ac.name+(dayStop?"\n Day stop: yes (+$"+(last.ac.day||DAY_STOP)+")":"")+
    "\n Est. flight time: "+fmtTime(last.oneway+TAXI/2)+" (~"+Math.round(last.dist)+" nm)"+
    (l.email?"\n Email: "+l.email:"")+(l.phone?"\n Phone: "+l.phone:"");
   wa.href="https://wa.me/"+WA_NUMBER+"?text="+encodeURIComponent(msg);
   closeModal();
 });
 var rq=root.querySelector(".q-rq");
 if(rq)rq.addEventListener("click",function(e){
   if(!last.ac){e.preventDefault();run(true);return;}
   if(!leadOk()){e.preventDefault();return;}
   var f=document.querySelector("#quote-form form")||document.querySelector("form[data-formsubmit]");
   if(!f){e.preventDefault();closeModal();
     location.href="/quote/?from="+encodeURIComponent(last.A[0])+"&to="+encodeURIComponent(last.bLabel)+"&pax="+last.pax+"#quote-form";return;}
   if(f){var l=lead();
    [["route_from",last.A[0]],["route_to",last.bLabel],["pax",last.pax],["aircraft",last.ac.name],
     ["date",(root.querySelector(".q-date")||{}).value],["phone",l.phone]].forEach(function(kv){
      var x=f.querySelector('[name="'+kv[0]+'"]');if(x&&kv[1])x.value=kv[1];});
    var em=f.querySelector('[name="email"]');if(em&&l.email)em.value=l.email; }
   closeModal();
   if(f){e.preventDefault();var t=document.getElementById("quote-form");if(t)t.scrollIntoView({behavior:"smooth"});}
 });
 // URL prefill (full tool)
 var p=new URLSearchParams(location.search);
 if(p.get("from"))(root.querySelector(".q-from")||{}).value=p.get("from");
 if(p.get("to"))(root.querySelector(".q-to")||{}).value=p.get("to");
 if(p.get("pax"))(root.querySelector(".q-pax")||{}).value=p.get("pax");
 if(p.get("from")&&p.get("to"))run(true);
}
/* ---- modal ---- */
function modalEl(){return document.getElementById("qmodal");}
function openModal(){var mo=modalEl();if(!mo)return;mo.hidden=false;document.body.style.overflow="hidden";
 var t=mo.querySelector(".qmap");if(t)initTool(t);var c=mo.querySelector(".q-from");if(c)setTimeout(function(){c.focus();},50);}
function closeModal(){var mo=modalEl();if(!mo||mo.hidden)return;mo.hidden=true;document.body.style.overflow="";}
window.KEAopenQuote=openModal;
document.addEventListener("click",function(e){
 var open=e.target.closest('[data-quote-open], a[href="/quote/"]');
 if(open){e.preventDefault();openModal();return;}
 if(e.target.closest(".qmodal-x")||e.target.classList.contains("qmodal")){closeModal();}
});
document.addEventListener("keydown",function(e){
 if(e.key==="Escape"){closeModal();return;}
 var mo=modalEl();if(!mo||mo.hidden||e.key!=="Tab")return;
 var f=mo.querySelectorAll("button, input, select, a[href]");if(!f.length)return;
 var first=f[0],last2=f[f.length-1];
 if(e.shiftKey&&document.activeElement===first){e.preventDefault();last2.focus();}
 else if(!e.shiftKey&&document.activeElement===last2){e.preventDefault();first.focus();}
});
function boot(){document.querySelectorAll(".qmap").forEach(function(r){
 // don't auto-init the hidden modal tool until opened (saves map build); init visible ones
 if(!r.closest(".qmodal"))initTool(r);});}
if(document.readyState!=="loading")boot();else document.addEventListener("DOMContentLoaded",boot);
})();
